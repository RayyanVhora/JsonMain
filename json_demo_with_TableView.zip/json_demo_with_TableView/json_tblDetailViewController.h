//
//  json_tblDetailViewController.h
//  json_demo1
//
//  Created by Peerbits Solution on 04/12/12.
//
//

#import <UIKit/UIKit.h>
@interface json_tblDetailViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{

    IBOutlet UITableView *tblDetail;
    NSArray *hedaing;
    NSMutableArray *detail;
    NSString *name;
    NSString *activity;
    NSString *status;
    int loanamount;

}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil DataArray:(NSArray *)array;
+(void) getInitialDataToDisplay:(NSString *)dbPath;
+ (void) finalizeStatements;
@end
