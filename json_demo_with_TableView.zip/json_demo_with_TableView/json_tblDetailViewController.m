//
//  json_tblDetailViewController.m
//  json_demo1
//
//  Created by Peerbits Solution on 04/12/12.
//
//

#import "json_tblDetailViewController.h"
#import "json_demo1AppDelegate.h"

static sqlite3 *database = nil;
static sqlite3_stmt *selectStmt = nil;
static sqlite3_stmt *deleteStmt = nil;
static sqlite3_stmt *addStmt = nil;

@interface json_tblDetailViewController ()

@end

@implementation json_tblDetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil DataArray:(NSArray *)array
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        NSLog(@"Array===>%@",[array objectAtIndex:0]);
        detail= [[NSMutableArray alloc]initWithArray:array];
        NSLog(@"Detail===>%@",[[detail valueForKey:@"activity"] objectAtIndex:0]);
        hedaing=[[NSArray alloc]initWithArray:[NSArray arrayWithObjects:@"activity",@"basket_amount",@"borrower_count",@"funded_amount",@"id",@"name",@"loan_amount",@"partner_id",@"planned_expiration_date",@"posted_date",@"sector",@"status",@"use",nil]];
        
        name=[[detail valueForKey:@"name" ] objectAtIndex:0];
       
        activity=[[detail valueForKey:@"activity" ] objectAtIndex:0];
        status=[[detail valueForKey:@"status"] objectAtIndex:0];
        loanamount=[[[detail valueForKey:@"loan_amount"]objectAtIndex:0]integerValue ];
        
        [self addData];
        [self selectStatement];

}
    return self;
}

+(void) getInitialDataToDisplay:(NSString *)dbPath
{
	
	if (sqlite3_open([dbPath UTF8String], &database) == SQLITE_OK) {
        
        NSLog(@"Database Open===>%@",dbPath);
    }else
    {
		sqlite3_close(database);
    }
    
}

- (void) selectStatement {
	
	if(selectStmt == nil) {
		const char *sql = "select name, activity,status, loanamount from tblData";
        sqlite3_stmt *selectstmt;
		if(sqlite3_prepare_v2(database, sql, -1, &selectstmt, NULL) != SQLITE_OK) {
            NSAssert1(0, @"Error while creating add statement. '%s'", sqlite3_errmsg(database));
        }
        else
        {
            while(sqlite3_step(selectstmt) == SQLITE_ROW) {
				
               NSString *name1 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(selectstmt, 0)];
                 NSString *activity1 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(selectstmt, 1)];
                 NSString *status1 = [NSString stringWithUTF8String:(char *)sqlite3_column_text(selectstmt, 2)];
				NSInteger loanamount1 = sqlite3_column_int(selectstmt, 3);
			
                NSLog(@"Name===>%@,\nActivity===>%@,\nstatus===>%@\nloanAmount===>%d",name1,activity1,status1,loanamount1);
                
			}
        }
    }
}


- (void) addData {
	
	if(addStmt == nil) {
        
		const char *sql = "insert into tblData(name, activity,status,loanamount) Values(?,?,?,?)";
		if(sqlite3_prepare_v2(database, sql, -1, &addStmt, NULL) != SQLITE_OK)
			NSAssert1(0, @"Error while creating add statement. '%s'", sqlite3_errmsg(database));
	}
	
	sqlite3_bind_text(addStmt, 1, [name UTF8String], -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(addStmt, 2, [activity UTF8String], -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(addStmt, 3, [status UTF8String], -1, SQLITE_TRANSIENT);
	sqlite3_bind_int(addStmt, 4, loanamount );
	
	if(SQLITE_DONE != sqlite3_step(addStmt))
		NSAssert1(0, @"Error while inserting data. '%s'", sqlite3_errmsg(database));
	else
		//SQLite provides a method to get the last primary key inserted by using sqlite3_last_insert_rowid
		//coffeeID = sqlite3_last_insert_rowid(database);
        NSLog(@"Inserting Complete");
	//Reset the add statement.
	sqlite3_reset(addStmt);
}

+ (void) finalizeStatements {
    if(database) sqlite3_close(database);
	if(deleteStmt) sqlite3_finalize(deleteStmt);
	if(addStmt) sqlite3_finalize(addStmt);
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
   // NSLog(@"%d===>In Table",[self.aid count]);
    
    return [hedaing count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    
    
    static NSString *CellIdentifier = @"Cell";
    // add a placeholder cell while waiting on table data
	
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] autorelease];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
    
    UILabel *lblHeading = [[UILabel alloc] initWithFrame:CGRectMake(7,10, 150, 15)];
    lblHeading.backgroundColor = [UIColor clearColor];
    [lblHeading setTextColor:[UIColor colorWithRed:179.0/255.0 green:179.0/255.0 blue:179.0/255.0 alpha:1.0]];
    lblHeading.font=[UIFont fontWithName:@"HelveticaLTStd-Roman" size:12];
    lblHeading.textAlignment = UITextAlignmentLeft;
    lblHeading.text = [hedaing objectAtIndex:indexPath.row];
    [cell.contentView addSubview:lblHeading];
    
    UILabel *lblDetail = [[UILabel alloc] initWithFrame:CGRectMake(7,26,300,25)];
    lblDetail.backgroundColor = [UIColor clearColor];
    [lblDetail setTextColor:[UIColor colorWithRed:60.0/255.0 green:60.0/255.0 blue:60.0/255.0 alpha:1.0]];
    lblDetail.font=[UIFont fontWithName:@"Helvetica-Bold" size:14];
    lblDetail.textAlignment = UITextAlignmentLeft;
    lblDetail.text=[NSString stringWithFormat:@"%@",[[detail valueForKey:[hedaing objectAtIndex:indexPath.row]]objectAtIndex:0]] ;
    [cell.contentView addSubview:lblDetail];
    
   
  //  cell.textLabel.text =[NSString stringWithFormat:@"%@",[self.aid objectAtIndex:indexPath.row]];
    // NSDictionary *temp=[self.mainLoan ]
    
	//cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    // Set up the cell
    return cell;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [tblDetail release];
    [super dealloc];
}
@end
