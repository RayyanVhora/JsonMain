//
//  json_demo1AppDelegate.m
//  json_demo1
//
//  Created by Marin Todorov on 2/24/11.
//  Copyright 2011 Marin Todorov. All rights reserved.
//

#import "json_demo1AppDelegate.h"
#import "json_tblMainViewController.h"
#import "JSON.h"
#import "json_tblDetailViewController.h"

#define kLatestKivaLoansURL @"http://api.kivaws.org/v1/loans/search.json?status=fundraising"

@implementation json_demo1AppDelegate

@synthesize window;
@synthesize viewController;
@synthesize responseData,loan;

#pragma mark -
#pragma mark Application lifecycle

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
     activity = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(120, 180, 80 , 80)];
    [activity setBackgroundColor:[UIColor clearColor]];
    [activity setActivityIndicatorViewStyle: UIActivityIndicatorViewStyleWhiteLarge];
    [window addSubview: activity];
    [activity release];
    
    [activity startAnimating];
    activity.hidden = FALSE;
    
    //For Database
    [self copyDatabaseIfNeeded];
    [json_tblDetailViewController getInitialDataToDisplay:[self getDBPath]];
   
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
   // [self loadData];
    
    // Override point for customization after application launch.
    self.viewController = [[[json_tblMainViewController alloc] initWithNibName:@"json_tblMainViewController" bundle:nil] autorelease];
    [self loadData];
    // self.window.rootViewController = self.viewController;
    [self.window makeKeyAndVisible];
    
   
    return YES;
}

- (void) copyDatabaseIfNeeded {
	
	//Using NSFileManager we can perform many file system operations.
	NSFileManager *fileManager = [NSFileManager defaultManager];
	NSError *error;
	NSString *dbPath = [self getDBPath];
	BOOL success = [fileManager fileExistsAtPath:dbPath];
	
	if(!success) {
		
		NSString *defaultDBPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"dbLoan.sqlite"];
		success = [fileManager copyItemAtPath:defaultDBPath toPath:dbPath error:&error];
		
		if (!success)
			NSAssert1(0, @"Failed to create writable database file with message '%@'.", [error localizedDescription]);
	}
}

- (NSString *) getDBPath {
	
	//Search for standard documents using NSSearchPathForDirectoriesInDomains
	//First Param = Searching the documents directory
	//Second Param = Searching the Users directory and not the System
	//Expand any tildes and identify home directories.
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory , NSUserDomainMask, YES);
	NSString *documentsDir = [paths objectAtIndex:0];
	return [documentsDir stringByAppendingPathComponent:@"SQL.sqlite"];
}


-(void)loadData
{
    NSLog(@"In Load Data");
   	self.responseData = [NSMutableData data];
     
     NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:kLatestKivaLoansURL]];
     [[NSURLConnection alloc] initWithRequest:request delegate:self];
     }
     
     - (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
     [responseData setLength:0];
     }
     
     - (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
     [responseData appendData:data];
     }
     
     - (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
     [connection release];
     self.responseData = nil;
}

#pragma mark -
#pragma mark Process loan data
- (void)connectionDidFinishLoading:(NSURLConnection *)connection {

    NSLog(@"In Connection");

 [connection release];
 
 NSString *responseString = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
 self.responseData = nil;
 
 loan = (NSDictionary*)[responseString JSONValue] ;
    NSLog(@"%@",loan);
    self.viewController.mainLoan =[loan copy];
    
    /*
     // Code for Check JSON return data in "Dictionary" or "Array"
     
     id results = [responseString JSONValue];
    if ([results isKindOfClass: [NSArray class]])
    {
        NSLog(@"Array");// probably iterate through whtever is in it
    }
    else if ([results isKindOfClass: [NSDictionary class]])
    {
        NSLog(@"Dic==");
        // dictionary at the top level.  Hooray!
    }*/
    NSLog(@"\n\n\n\nMain loan====>%@",self.viewController.mainLoan);
    UINavigationController *navigation =[[UINavigationController alloc]initWithRootViewController:self.viewController];
    navigation.navigationBar.hidden=YES;
    activity.hidden = TRUE;
    
    [activity stopAnimating];
    self.window.rootViewController = navigation;
 [responseString release];
 
}

- (void)applicationWillResignActive:(UIApplication *)application {
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, called instead of applicationWillTerminate: when the user quits.
     */
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
    /*
     Called as part of  transition from the background to the inactive state: here you can undo many of the changes made on entering the background.
     */
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}


- (void)applicationWillTerminate:(UIApplication *)application {
    
        [json_tblDetailViewController finalizeStatements];
    
}


#pragma mark -
#pragma mark Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    /*
     Free up as much memory as possible by purging cached data objects that can be recreated (or reloaded from disk) later.
     */
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
