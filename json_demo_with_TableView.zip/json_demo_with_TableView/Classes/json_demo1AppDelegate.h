//
//  json_demo1AppDelegate.h
//  json_demo1
//
//  Created by Marin Todorov on 2/24/11.
//  Copyright 2011 Marin Todorov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FMDatabase.h"
@class json_tblMainViewController;

@interface json_demo1AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    json_tblMainViewController *viewController;
    NSDictionary* loan;
    UIActivityIndicatorView *activity;
    NSString *databaseName;
    NSString *databasePath;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet json_tblMainViewController *viewController;
@property (retain, nonatomic) NSMutableData* responseData;
@property (retain, nonatomic) NSDictionary* loan;
@property (retain, nonatomic) NSString *databaseName;
@property(retain, nonatomic) NSString *databasePath;
-(void)loadData;


- (void) copyDatabaseIfNeeded;
- (NSString *) getDBPath;
@end

