//
//  json_tblMainViewController.h
//  json_demo1
//
//  Created by Peerbits Solution on 29/11/12.
//
//

#import <UIKit/UIKit.h>
#import "json_demo1AppDelegate.h"
#import "DarckWaitView.h"
@interface json_tblMainViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{

    
    IBOutlet UITableView *tblMain;
    NSMutableData* responseData;
    NSDictionary* loan;
     NSArray* mainLoan;
    
    NSMutableArray *aid;
    DarckWaitView *dr;
    NSArray* dataField;
   // json_demo1AppDelegate *app;
    

}
 @property (retain, nonatomic) NSDictionary* mainLoan;
 @property (retain, nonatomic) NSMutableData* responseData;
@property (retain, nonatomic) NSMutableArray *aid;
@property (retain, nonatomic) IBOutlet UITableView *tblMain;
@property (retain, nonatomic) NSArray* dataField;
//@property  (nonatomic,strong) json_demo1AppDelegate *app;
@end
