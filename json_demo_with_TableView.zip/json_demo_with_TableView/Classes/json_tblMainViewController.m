//
//  json_tblMainViewController.m
//  json_demo1
//
//  Created by Peerbits Solution on 29/11/12.
//
//

#import "json_tblMainViewController.h"
#import "JSON.h"
#import "json_demo1AppDelegate.h"
#import "json_tblDetailViewController.h"

#define kLatestKivaLoansURL @"http://api.kivaws.org/v1/loans/search.json?status=fundraising"
@interface json_tblMainViewController ()

@end

@implementation json_tblMainViewController
@synthesize responseData;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    aid=[[NSMutableArray alloc]init];
    self.aid=[[self.mainLoan valueForKey:@"loans" ]valueForKey:@"name"];
    
    self.dataField = [[NSArray alloc] initWithArray:[self.mainLoan objectForKey:@"loans"]];
    
   // NSDictionary *dic1=[self.mainLoan valueForKey:@"loans"];
    
 //  NSLog(@"keys===>%@",dic1);
   // NSArray *values = [dic1 allKeys];
    NSLog(@"Values==>%@",[self.dataField objectAtIndex:0]);
       NSLog(@"aid===>%@",aid);
    NSLog(@"Rayyan");
 //   self.app=(json_demo1AppDelegate *)[[UIApplication sharedApplication] delegate];
         //[self loadData];
     [dr showWithMessage:nil];
    
    // aid=[app.loan valueForKey:@"id"];
    //NSLog(@"%@",aid);
    //  [tblMain reloadData];
    
    
    // Do any additional setup after loading the view from its nib.

}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:NO];
    NSLog(@"View Will Appear===>%@",self.mainLoan);
    NSLog(@"View Will Appear");

   [self.tblMain reloadData];
    // aid=[[NSMutableArray alloc]initWithObjects:[app.loan valueForKey:@"id"],nil];
   // NSLog(@"%@",loan);
    NSLog(@"Rayyan");

    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSLog(@"%d===>In Table",[self.aid count]);
    
    return [self.aid count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
   
    
    static NSString *CellIdentifier = @"Cell";
    // add a placeholder cell while waiting on table data
	
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] autorelease];
    }
    //cell.selectionStyle=UITableViewCellSelectionStyleNone;
    
     //  cell.textLabel.text=[NSString stringWithFormat:@"%@",[aid objectAtIndex:indexPath.row]];

         cell.textLabel.font=[UIFont fontWithName:@"HelveticaLTStd-Roman" size:16];
            cell.textLabel.text =[NSString stringWithFormat:@"%@",[self.aid objectAtIndex:indexPath.row]];
   // NSDictionary *temp=[self.mainLoan ]
    
	//cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    // Set up the cell
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Navigation logic -- create and push a new view controller
    
    
    NSMutableArray *temp=[[NSMutableArray alloc]init];
    [temp addObject:[self.dataField objectAtIndex:indexPath.row]];
	json_tblDetailViewController *detail=[[json_tblDetailViewController alloc]initWithNibName:@"json_tblDetailViewController" bundle:nil DataArray:[NSArray arrayWithArray:temp]];
		
	[self.navigationController pushViewController:detail animated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc {
    [tblMain release];
    [_tblMain release];
    [super dealloc];
}
@end
